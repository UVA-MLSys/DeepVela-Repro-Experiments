# Copyright 2021 Arm Limited and affiliates.
# Copyright (c) 2019 NVIDIA CORPORATION. All rights reserved.
# Licensed under the Apache License, Version 2.0 (the "License");

"""SQuAD records and an intentionally unspecified feature interface."""

import json
import tokenization


class SquadExample(object):
    """A single training/test example for simple sequence classification."""

    def __init__(self, qas_id, question_text, doc_tokens, orig_answer_text=None,
                 start_position=None, end_position=None, is_impossible=False):
        self.qas_id = qas_id
        self.question_text = question_text
        self.doc_tokens = doc_tokens
        self.orig_answer_text = orig_answer_text
        self.start_position = start_position
        self.end_position = end_position
        self.is_impossible = is_impossible

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        s = ""
        s += "qas_id: %s" % (tokenization.printable_text(self.qas_id))
        s += ", question_text: %s" % (tokenization.printable_text(self.question_text))
        s += ", doc_tokens: [%s]" % (" ".join(self.doc_tokens))
        if self.start_position:
            s += ", start_position: %d" % (self.start_position)
        if self.start_position:
            s += ", end_position: %d" % (self.end_position)
        if self.start_position:
            s += ", is_impossible: %r" % (self.is_impossible)
        return s


class InputFeatures(object):
    """A single set of supplied feature tensors."""

    def __init__(self, unique_id, example_index, doc_span_index, tokens,
                 token_to_orig_map, token_is_max_context, input_ids, input_mask,
                 segment_ids, start_position=None, end_position=None,
                 is_impossible=None):
        self.unique_id = unique_id
        self.example_index = example_index
        self.doc_span_index = doc_span_index
        self.tokens = tokens
        self.token_to_orig_map = token_to_orig_map
        self.token_is_max_context = token_is_max_context
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.segment_ids = segment_ids
        self.start_position = start_position
        self.end_position = end_position
        self.is_impossible = is_impossible


def read_squad_examples(input_file, is_training,
                        version_2_with_negative=False):
    """Read a SQuAD json file into a list of SquadExample."""
    with open(input_file) as reader:
        input_data = json.load(reader)["data"]

    def is_whitespace(c):
        if c == " " or c == "\t" or c == "\r" or c == "\n" or ord(c) == 0x202F:
            return True
        return False

    examples = []
    for entry in input_data:
        for paragraph in entry["paragraphs"]:
            paragraph_text = paragraph["context"]
            doc_tokens = []
            char_to_word_offset = []
            prev_is_whitespace = True
            for c in paragraph_text:
                if is_whitespace(c):
                    prev_is_whitespace = True
                else:
                    if prev_is_whitespace:
                        doc_tokens.append(c)
                    else:
                        doc_tokens[-1] += c
                    prev_is_whitespace = False
                char_to_word_offset.append(len(doc_tokens) - 1)
            for qa in paragraph["qas"]:
                qas_id = qa["id"]
                question_text = qa["question"]
                start_position = None
                end_position = None
                orig_answer_text = None
                is_impossible = False
                if is_training:
                    if version_2_with_negative:
                        is_impossible = qa["is_impossible"]
                    if (len(qa["answers"]) != 1) and (not is_impossible):
                        raise ValueError("For training, each question should have exactly 1 answer.")
                    if not is_impossible:
                        answer = qa["answers"][0]
                        orig_answer_text = answer["text"]
                        answer_offset = answer["answer_start"]
                        answer_length = len(orig_answer_text)
                        start_position = char_to_word_offset[answer_offset]
                        end_position = char_to_word_offset[answer_offset + answer_length - 1]
                        actual_text = " ".join(doc_tokens[start_position: (end_position + 1)])
                        cleaned_answer_text = " ".join(tokenization.whitespace_tokenize(orig_answer_text))
                        if actual_text.find(cleaned_answer_text) == -1:
                            print("Could not find answer: '%s' vs. '%s'", actual_text,
                                  cleaned_answer_text)
                            continue
                    else:
                        start_position = -1
                        end_position = -1
                        orig_answer_text = ""
                example = SquadExample(
                    qas_id=qas_id, question_text=question_text,
                    doc_tokens=doc_tokens, orig_answer_text=orig_answer_text,
                    start_position=start_position, end_position=end_position,
                    is_impossible=is_impossible)
                examples.append(example)
    return examples


def _missing_input_presentation(*args, **kwargs):
    raise RuntimeError(
        "The packaged evidence does not specify the reference input presentation."
    )


def _check_is_max_context(*args, **kwargs):
    return _missing_input_presentation(*args, **kwargs)


def _improve_answer_span(*args, **kwargs):
    return _missing_input_presentation(*args, **kwargs)


def convert_examples_to_features(*args, **kwargs):
    return _missing_input_presentation(*args, **kwargs)
