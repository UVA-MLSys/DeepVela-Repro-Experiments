# coding=utf-8
# Copyright 2021 Arm Limited and affiliates.
# Copyright (c) 2020 NVIDIA CORPORATION. All rights reserved.
# Copyright 2018 The Google AI Language Team Authors.

"""Load feature records and raw logits; logits-to-score binding is withheld."""

import argparse
import collections
import json
import os
import pickle
import sys

import numpy as np
import pkg_resources
from transformers import BertTokenizer

sys.path.insert(0, os.path.dirname(__file__))
installed = {pkg.key for pkg in pkg_resources.working_set}
if "tensorflow" in installed:
    import tensorflow
    sys.path.insert(0, os.path.join(os.path.dirname(__file__),
                    "DeepLearningExamples", "TensorFlow", "LanguageModeling", "BERT"))
elif "torch" in installed:
    import torch
    sys.path.insert(0, os.path.join(os.path.dirname(__file__),
                    "DeepLearningExamples", "PyTorch", "LanguageModeling", "BERT"))
try:
    from create_squad_data import convert_examples_to_features, read_squad_examples
except ImportError:
    raise Exception("Error importing local modules")


max_seq_length = 384
max_query_length = 64
doc_stride = 128

RawResult = collections.namedtuple(
    "RawResult", ["unique_id", "start_logits", "end_logits"])

dtype_map = {
    "int8": np.int8, "int16": np.int16, "int32": np.int32,
    "int64": np.int64, "float16": np.float16, "float32": np.float32,
    "float64": np.float64}


def _missing_evaluation_binding(*args, **kwargs):
    raise RuntimeError(
        "The packaged evidence does not specify the logits-to-score evaluation binding."
    )


def get_final_text(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def _get_best_indexes(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def _compute_softmax(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def write_predictions(raw_start_end_logits, feature_records, question_ids,
                      contexts, annotations, *args, **kwargs):
    """Generic withheld interface: logits and records to SQuAD metrics."""
    return _missing_evaluation_binding(raw_start_end_logits, feature_records,
                                       question_ids, contexts, annotations)


def load_loadgen_log(log_path, eval_features, dtype=np.float32,
                     output_transposed=False):
    with open(log_path) as f:
        predictions = json.load(f)
    results = []
    for prediction in predictions:
        qsl_idx = prediction["qsl_idx"]
        if output_transposed:
            logits = np.frombuffer(bytes.fromhex(prediction["data"]), dtype).reshape(2, -1)
            logits = np.transpose(logits)
        else:
            logits = np.frombuffer(bytes.fromhex(prediction["data"]), dtype).reshape(-1, 2)
        seq_length = logits.shape[0]
        start_logits = np.ones(max_seq_length) * -10000.0
        end_logits = np.ones(max_seq_length) * -10000.0
        start_logits[:seq_length] = logits[:, 0]
        end_logits[:seq_length] = logits[:, 1]
        results.append(RawResult(
            unique_id=eval_features[qsl_idx].unique_id,
            start_logits=start_logits.tolist(), end_logits=end_logits.tolist()))
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vocab_file",
        default="build/data/bert_tf_v1_1_large_fp32_384_v2/vocab.txt")
    parser.add_argument("--val_data", default="build/data/dev-v1.1.json")
    parser.add_argument("--log_file", default="build/logs/mlperf_log_accuracy.json")
    parser.add_argument("--out_file", default="build/result/predictions.json")
    parser.add_argument("--features_cache_file", default="eval_features.pickle")
    parser.add_argument("--output_transposed", action="store_true")
    parser.add_argument("--output_dtype", default="float32", choices=dtype_map.keys())
    parser.add_argument("--max_examples", type=int)
    args = parser.parse_args()
    output_dtype = dtype_map[args.output_dtype]
    print("Reading examples...")
    eval_examples = read_squad_examples(
        input_file=args.val_data, is_training=False, version_2_with_negative=False)
    eval_features = []
    cache_path = args.features_cache_file
    if os.path.exists(cache_path):
        print("Loading cached features from '%s'..." % cache_path)
        with open(cache_path, "rb") as cache_file:
            eval_features = pickle.load(cache_file)
    else:
        print("No cached features at '%s'... converting from examples..." % cache_path)
        print("Creating tokenizer...")
        tokenizer = BertTokenizer(args.vocab_file)
        print("Converting examples to features...")
        def append_feature(feature):
            eval_features.append(feature)
        convert_examples_to_features(
            examples=eval_examples, tokenizer=tokenizer, max_seq_length=max_seq_length,
            doc_stride=doc_stride, max_query_length=max_query_length, is_training=False,
            output_fn=append_feature, verbose_logging=False)
        print("Caching features at '%s'..." % cache_path)
        with open(cache_path, "wb") as cache_file:
            pickle.dump(eval_features, cache_file)
    print("Loading LoadGen logs...")
    results = load_loadgen_log(args.log_file, eval_features, output_dtype,
                               args.output_transposed)
    write_predictions(results, eval_features,
                      [example.qas_id for example in eval_examples],
                      [example.doc_tokens for example in eval_examples], None)


if __name__ == "__main__":
    main()
