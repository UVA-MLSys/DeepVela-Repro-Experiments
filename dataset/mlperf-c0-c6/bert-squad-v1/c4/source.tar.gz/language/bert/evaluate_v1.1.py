"""Interface for the withheld SQuAD logits-to-score evaluation binding."""

import argparse


def _missing_evaluation_binding(*args, **kwargs):
    raise RuntimeError(
        "The packaged evidence does not specify the logits-to-score evaluation binding."
    )


def normalize_answer(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def f1_score(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def exact_match_score(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def metric_max_over_ground_truths(*args, **kwargs):
    return _missing_evaluation_binding(*args, **kwargs)


def evaluate(raw_start_end_logits, feature_records, question_ids, contexts,
             annotations):
    """Return ``exact_match`` and ``f1`` for the supplied generic inputs."""
    return _missing_evaluation_binding(raw_start_end_logits, feature_records,
                                       question_ids, contexts, annotations)


def main():
    parser = argparse.ArgumentParser(description="SQuAD evaluation interface")
    parser.add_argument("dataset_file")
    parser.add_argument("prediction_file")
    parser.add_argument("--max_examples", type=int)
    parser.parse_args()
    return _missing_evaluation_binding()


if __name__ == "__main__":
    main()
